<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Slaptažodžio priminimo kalbos eilutės
    |--------------------------------------------------------------------------
    |
    | Sekančios kalbos eilutės yra numatytos elutės, atitinkančios priežastims,
    | pateikiamoms slatažodžių tarpininko, kai nepavyksta slaptažodžio atnaujinimo
    | bandymas, tokioms kaip negaliojanti žymė ar neteisingas naujas slaptažodis..
    |
    */

    'reset'     => 'Nustatytas naujas slaptažodis!',
    'sent'      => 'Naujo slaptažodžio nustatymo nuoroda išsiųsta',
    'throttled' => 'Palaukite prieš tęsdami.',
    'token'     => 'Šis slaptažodžio raktas yra neteisingas.',
    'user'      => 'Vartotojas su tokiu el. paštu nerastas.',
];
