<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Kimlik Doğrulama Dil Satırları
    |--------------------------------------------------------------------------
    |
    | Kimlik doğrulama sırasında kullanıcıya görüntülememiz gereken çeşitli
    | mesajlar için aşağıdaki dil satırları kullanılır. Bu dil satırlarını
    | uygulamanızın gereksinimlerine göre, kolayca, değiştirebilirsiniz.
    |
    */

    'failed'   => 'Bu kimlik bilgileri kayıtlarımızla eşleşmiyor.',
    'throttle' => 'Çok fazla giriş denemesi. :seconds saniye sonra lütfen tekrar deneyin.',

];
